const atendimento = require('./atendimento')
const cliente = require('./cliente')
const pet = require('./pet')
const servico = require('./servico')

module.exports = {
  atendimento,
  cliente,
  pet,
  servico
}
